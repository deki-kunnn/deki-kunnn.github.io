<?php
	include_once 'admin.session.php';
?>


<div class="container">
	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
            <!-- Komponen navbar -->	
			<ul class="nav pull-left">
				<li ><a href="home.php"><b class="text-error"> Home</b></a></li>
				
				<li><a href="member.php?hal=1" ><b  class="text-error"> Data Member </b></a></li>
				<li><a href="berita.php"><b  class="text-error"> Data Lapangan</b></a></li>
				
				<li><a href="pemesanan.php?hal=1"><b  class="text-error"> Data Pemesanan</b></a></li>
				<li><a href="logout.php"><b  class="text-error"> Logout</b></a></li>
				
				
				
<!--			<li><a href="laporan.php?hal=1"><b  class="text-error"> Laporan Pendapatan</b></a></li>
<!--			<li><a href="konfirmasi.php?hal=1"><b  class="text-error"> Data Konfirmasi</b></a></li>
				<li><a href="permintaan.php?hal=1"><b  class="text-error"> Data Permintaan</b></a></li>-->
					
				
				
			</ul>
			
		</div>
	</div>
</div>