<?php
	session_start();
	include_once('admin.session.php');
	$id	= $_GET['id'];
	
	mysqlI_query($koneksi,"delete from keterangan where id_konsultasi='$id'");
	mysqlI_query($koneksi,"delete from hasil_konsultasi where konsultasi='$id'");
	
	echo "<script language=javascript>
			window.alert('Hapus Berhasil');
			window.location='hasil.konsultasi.php?hal=1';
			</script>";
?>