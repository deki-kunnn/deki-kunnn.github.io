<?php
$host = 'localhost'; // Host MySQL
$user = 'root'; // Pengguna MySQL
$password = ''; // Kata sandi MySQL
$database = 'db_futsal'; // Nama database

// Buat koneksi
$koneksi = new mysqli($host, $user, $password, $database);

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
?>
