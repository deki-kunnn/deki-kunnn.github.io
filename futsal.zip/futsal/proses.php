<?php
session_start();
include_once("config/koneksi.php");

$user = mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM user WHERE id_user='$_SESSION[iduser]'"));

date_default_timezone_set('Asia/Jakarta');
$tgl_skr = date('Y-m-d H:i:s');
$tglmain = $_POST['tgl'] . ' ' . $_POST['jm'];
$lama = $_POST['lm']; // Just the hours

// Parse the hours and minutes separately
list($hours, $minutes) = explode(':', $_POST['lm']);
// Create a DateInterval object with the specified hours and minutes
$dateInterval = new DateInterval("PT{$hours}H{$minutes}M");

// Add hours to the specified date and time
$date = date_create($tglmain);
if ($dateInterval !== false) {
    date_add($date, $dateInterval); // Use the interval object
    $h1 = date_format($date, 'Y-m-d H:i:s');

    // Determine jenis (time slot) and corresponding harga (price)
    if ($_POST['jm'] >= "20:00:00" && $_POST['jm'] <= "23:00:00") {
        $jenis = "Malam";
        $harga = $_POST['h2'];
    } else {
        $jenis = "Siang";
        $harga = $_POST['h1'];
    }

    // Calculate total price
    $tot = $harga * $_POST['lm'];

    // Insert data into database
    $simpan = mysqli_query($koneksi, "INSERT INTO sewa VALUES('', '$_SESSION[iduser]', '$_POST[idlap]', NOW(), '$_POST[lm]', '$tglmain', '$h1', '$jenis', '$harga', '$tot')");

    if ($simpan) {
        echo "<script type='text/javascript'>alert('Pemesanan Berhasil...!!!');</script>";
        echo "<meta http-equiv='refresh' content='0; index.php?view=bayar'>";
    } else {
        echo "<meta http-equiv='refresh' content='0; index.php?view=pesan'>";
    }
} else {
    echo "Failed to create DateInterval."; // Output an error message if creating interval fails
}
?>
